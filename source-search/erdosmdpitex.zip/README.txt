Stronger sieve bounds and complete Type I source searches
for the Erdos-Straus equation

Authors: Deep Bhattacharjee, Tristan Romanov, Ushashi Bhattacharya.

Read erdosmdpi.pdf. The appendix and declarations are included in the PDF.
Compile main.tex from this directory with three pdflatex passes:
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
The article uses amsart. The PNG figures are already supplied.
Their editable TikZ sources are in figures/.

Exact verification, from this directory:
  python checks/python/source_search.py --limit 200000 --report source-search/verification.json
  python checks/python/source_census.py --limit 1000000 --report source-search/million-census.json
  python checks/python/two_channel.py

Repository: https://github.com/anaxia-research/ErdosProblem1
This archive is a single attachment containing the paper and supporting files.
